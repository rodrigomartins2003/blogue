@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    {{ __('Alterar Tag ') }}
                </div>
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    <form action="{{route ('posts.update',$tag->id)}}" method="PATCH" enctype="multipart/form-data">
                        @csrf

                        <div class="form-group">
                            <select multiple name="tags[]">
                                @foreach ($tags as $tag)
                                    <option value="{{$tag->id}}">{{$tag->tag}}</option>
                                @endforeach
                            </select>
                            @error('tag')
                                <div class="alert alert-danger">{{ $message }}</div>
                            @enderror
                        </div>
                                                
                        <button type="submit" class="btn btn-primary">Gravar</button>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
