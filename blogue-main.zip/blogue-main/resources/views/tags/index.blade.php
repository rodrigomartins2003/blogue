@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    {{ __('Lista de Tags ') }}
                </div>
                <div class="card-body">
                    @forelse ($tags as $tag)
                        <h6 class="card-subtitle mb-2 badge badge-secondary">{{$tag->tag}}</h6>
                        <a href="{{route('tags.edit',$tag->id)}}" class="btn btn-primary btn-sm">Alterar</a>
                    @empty
                        <p>Ainda sem tags</p>
                    @endforelse  
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
