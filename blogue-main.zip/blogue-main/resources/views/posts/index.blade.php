@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">

                <h3>Lista de Publicações</h3>
                @forelse ($posts as $post)
                    <div class="card mb-3" style="max-width: 540px;">
                        <div class="row g-0">
                        <div class="col-md-4">
                            
                            @if ($post->imagem == null)
                                <img src="{{asset('appimages/semimagem.png')}}" alt="{{$post->intro}}" class="img-fluid">
                            @else
                                <img src="{{asset('appimages/noticias/'.$post->imagem)}}" alt="{{$post->intro}}" class="img-fluid">
                            @endif
                            
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                            <h5 class="card-title">{{$post->titulo}}</h5>
                            @foreach ($post->tags as $tag)
                                <span class="badge badge-success">{{$tag->tag}}</span>    
                            @endforeach
                            <span class="badge badge-secondary">{{$post->categoria->categorianome}}</span>                            
                            <p class="card-text">{{$post->intro}}</p>
                            <a href="{{$post->link}}" class="btn btn-primary" target="blank">{{$post->textolink}}</a>
                            <a href="{{route('posts.show',$post->id)}}" class="btn btn-primary">Ver mais</a>
                            <p class="card-text text-right"><small class="text-muted">Criado por <strong>{{$post->user->name}}</strong> {{$post->created_at->diffforhumans()}}<br>Última alteração {{$post->updated_at->diffforhumans()}}</small></p>
                            <p class="text-right">
                                <a href="{{route('posts.show',$post->id)}}" class="btn btn-sm btn-outline-secondary">+</a>
                            </p>
                        </div>
                        </div>
                        </div>
                    </div>
                @empty
                    <p>Ainda sem publicações</p>
                    <tr>
                        <td colspan="4">Ainda sem posts</td>
                    </tr>
    
                @endforelse                
                  
            </div>
        </div>
    </div>
@endsection