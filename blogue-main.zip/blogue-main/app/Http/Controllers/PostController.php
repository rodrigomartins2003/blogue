<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use App\Models\Post;
use App\Models\Tag;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $posts = Post::all();
        return view('posts.index',compact('posts'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categorias = Categoria::orderBy('categorianome')->get(); 
        $tags = Tag::orderBy('tag')->get();
        return view('posts.create', compact('categorias','tags'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Validação 
        $data = $request->validate([
            'titulo' => 'required|max:255|unique:posts',
            'intro' => 'required|max:255',
            'corpo' => 'required',
            'textolink' => 'max:255',
            'link' => 'url|max:255',
            'categoria' => 'required|exists:categorias,id',
            'imagem' => 'image|mimes:jpg,jpeg,png|max:5000'
        ]);
        //Gravar na BD
        $posts = new Post;
        $posts->titulo = $data['titulo'];
        $posts->intro = $data['intro'];
        $posts->corpo = $data['corpo'];
        $posts->textolink = $data['textolink'];
        $posts->link = $data['link'];
        $posts->user_id = Auth::user()->id;
        $posts->categoria_id = $data['categoria'];
        if ($request->has('imagem')) {
            $img = $request->file('imagem'); //Pegar na imagem introduzaida no formulário, Coloca-la numa vareável temportária(img)
            $imgnome = time() . '.' . $img->getClientOriginalExtension(); //Construir um nome para a imagem para evitar a subreposição de imagens com o mesmo nome
            $path = 'appimages/noticias/'; //Definição do local onde a imagem vai ser armazenada
            $img->move($path,$imgnome); //Copiar o ficheiro da vareável temporária para o local que definimos
            $posts->imagem = $imgnome; //Guardar o nome da imagem na BaseDados
        }
        $posts->save();
        $posts->tags()->attach(request('tags'));
        //REdirecionar para o Formm das Categorias com mensagem de feedback
        return redirect (route('posts.index'))->with('fm-success','Post criada com sucesso');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $post = Post::findOrFail($id);
        return view('posts.show',compact('post'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $post = Post::findOrFail($id);
        $categorias = Categoria::orderBy('categorianome')->get();
        $tags = Tag::orderBy('tag')->get();
        return view('posts.edit', compact('post','categorias','tags'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //Validação 
        $data = $request->validate([
            'titulo' => 'required|min:3|max:255',
            'intro' => 'required|max:255',
            'corpo' => 'required',
            'textolink' => 'max:255',
            'link' => 'url|max:255',
            'categoria' => 'required|exists:categorias,id',
            'imagem' => 'image|mimes:jpg,jpeg,png|max:5000'
        ]);
        //Gravar na BD
        $post = Post::findOrFail($id);
        Post::where('id', $id)->update([
            'titulo' => $data['titulo'],
            'intro'=>$data['intro'],
            'corpo'=>$data['corpo'],
            'textolink'=>$data['textolink'],
            'link'=>$data['link'],
            'categoria_id'=>$data['categoria']
        ]);
        $post->tags()->sync(request('tags'));
        return redirect (route('posts.index'))->with('fm-success','Post alterada com sucesso');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
